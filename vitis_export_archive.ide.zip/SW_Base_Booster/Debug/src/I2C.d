src/I2C.o src/I2C.o: ../src/I2C.c ../src/I2C.h ../src/platform.h \
 ../src/platform_config.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_types.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters_ps.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/bspconfig.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xiic.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_assert.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xstatus.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xiic_l.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_io.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xreg_cortexa9.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm_gcc.h

../src/I2C.h:

../src/platform.h:

../src/platform_config.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_types.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters_ps.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/bspconfig.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xiic.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_assert.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xstatus.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xiic_l.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_io.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xreg_cortexa9.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm_gcc.h:
