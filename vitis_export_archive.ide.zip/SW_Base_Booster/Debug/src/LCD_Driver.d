src/LCD_Driver.o src/LCD_Driver.o: ../src/LCD_Driver.c \
 ../src/LCD_Driver.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xgpio.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_types.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_assert.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xstatus.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xgpio_l.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_io.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters_ps.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/bspconfig.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xreg_cortexa9.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm_gcc.h \
 ../src/LCD_SPI.h ../src/platform.h ../src/platform_config.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xstatus.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xspi.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xspi_l.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/sleep.h \
 ../src/fonts.h ../src/Delay.h

../src/LCD_Driver.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xgpio.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_types.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_assert.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xstatus.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xgpio_l.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_io.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters_ps.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/bspconfig.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xreg_cortexa9.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xpseudo_asm_gcc.h:

../src/LCD_SPI.h:

../src/platform.h:

../src/platform_config.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xstatus.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xspi.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xspi_l.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_printf.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/sleep.h:

../src/fonts.h:

../src/Delay.h:
