src/melody.o src/melody.o: ../src/melody.c ../src/melody.h

../src/melody.h:
