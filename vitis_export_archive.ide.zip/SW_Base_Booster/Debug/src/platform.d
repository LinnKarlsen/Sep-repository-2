src/platform.o src/platform.o: ../src/platform.c \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters_ps.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_cache.h \
 C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_types.h \
 ../src/platform_config.h

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xparameters_ps.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_cache.h:

C:/Users/fuent/Desktop/Intento_avance/Audioimplementado/Sep-repository-2-main/HW_Base_Booster_2025/HW_Base_Booster/export/HW_Base_Booster/sw/HW_Base_Booster/standalone_domain/bspinclude/include/xil_types.h:

../src/platform_config.h:
