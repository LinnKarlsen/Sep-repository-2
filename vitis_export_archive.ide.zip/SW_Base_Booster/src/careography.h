// careography.h
#ifndef CAREOGRAPHY_H
#define CAREOGRAPHY_H

#include <stdint.h>

// Definimos como int cada paso de baile:
#define NONE    0
#define LEFT    1
#define DOWN    2
#define UP      3
#define RIGHT   4
#define TURN_LEFT  5
#define TURN_RIGHT 6


#include <stdint.h>

#define MAX_STEPS 256 // Tamano maximo de la melodia (puede ampliarse)

// Definicion de struct tipo "Dance Data" (informacion asociada a la melodia completa)
typedef struct {
    const int *steps;   // Pointer que dirige al array del baile
    int length;         // Cantidad de steps que tiene el array
    int tempo;          // Tempo de la melodia
    const char *name;   // Nombre de la melodia
} DanceData;

// Definicion de struct tipo "Step" (informacion asociada a cada nota)
typedef struct {
	uint32_t dancemove; // frequency -> dancemove
    uint32_t duration;  // Duracion del paso de baile
} Step;   // Note -> Step

// Declaraciones externas
extern const DanceData *available_dances[]; // Puntero a las bailes disponibles
extern const int NUM_DANCES;  // Cantidad de bailes

// Funcion base utilizada para la inicializacion del baile:
void initialize_dance(const DanceData *danceData, Step *danceArray, int *danceLength);

#endif
