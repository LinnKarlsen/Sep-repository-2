#include "dance.h" // Header que contiene las funciones utilizadas
#include "careography.h" // Header que define la estructura de una nota
#include "xscugic.h" // "General Interrupt Controller"
#include "xtmrctr.h" // "Axi Timer
#include "xil_printf.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xil_io.h"
#include "Delay.h"
#include "LCD_GUI.h"

#include <stdint.h>

// Left arrow variables
extern int left_flag1;
extern int left_flag2;
extern int left_flag3;
extern int left_flag4;
extern int left_flag5;
extern int left_pose1;
extern int left_pose2;
extern int left_pose3;
extern int left_pose4;
extern int left_pose5;

// Right arrow variables
extern int right_flag1;
extern int right_flag2;
extern int right_flag3;
extern int right_flag4;
extern int right_flag5;
extern int right_pose1;
extern int right_pose2;
extern int right_pose3;
extern int right_pose4;
extern int right_pose5;

// Up arrow variables
extern int up_flag1;
extern int up_flag2;
extern int up_flag3;
extern int up_flag4;
extern int up_flag5;
extern int up_pose1;
extern int up_pose2;
extern int up_pose3;
extern int up_pose4;
extern int up_pose5;

// Down arrow variables
extern int down_flag1;
extern int down_flag2;
extern int down_flag3;
extern int down_flag4;
extern int down_flag5;
extern int down_pose1;
extern int down_pose2;
extern int down_pose3;
extern int down_pose4;
extern int down_pose5;

// Turn left variables
extern int turn_left_flag1;
extern int turn_left_flag2;
extern int turn_left_pose1;
extern int turn_left_pose2;

// Turn right variables
extern int turn_right_flag1;
extern int turn_right_flag2;
extern int turn_right_pose1;
extern int turn_right_pose2;

// For scoring
extern volatile int score;
extern volatile int joyx_val, joyy_val, acx_val;
extern int mic_val;
// Ventanas en las cuales accionar el joystick es punteable
extern int left_window1;
extern int left_window2;
extern int left_window3;
extern int left_window4;
extern int left_window5;
extern int right_window1;
extern int right_window2;
extern int right_window3;
extern int right_window4;
extern int right_window5;
extern int up_window1;
extern int up_window2;
extern int up_window3;
extern int up_window4;
extern int up_window5;
extern int down_window1;
extern int down_window2;
extern int down_window3;
extern int down_window4;
extern int down_window5;
// Se bloquea la ventana si ya se consigui� el punto
extern int blocked_left_window1;
extern int blocked_left_window2;
extern int blocked_left_window3;
extern int blocked_left_window4;
extern int blocked_left_window5;
extern int blocked_right_window1;
extern int blocked_right_window2;
extern int blocked_right_window3;
extern int blocked_right_window4;
extern int blocked_right_window5;
extern int blocked_up_window1;
extern int blocked_up_window2;
extern int blocked_up_window3;
extern int blocked_up_window4;
extern int blocked_up_window5;
extern int blocked_down_window1;
extern int blocked_down_window2;
extern int blocked_down_window3;
extern int blocked_down_window4;
extern int blocked_down_window5;
extern int blocked_turn_left_window1;
extern int blocked_turn_left_window2;
extern int blocked_turn_right_window1;
extern int blocked_turn_right_window2;

// Definimos una variable modificada dentro de la interrupcion:
volatile int current_step = 0; // Indice de la nota actual

// Melody data
Step dance[MAX_STEPS]; // Adjust MAX_NOTES if needed
int dance_length = 0;  // Length of the current melody

// Instancia del AXI Timer:
XTmrCtr TimerInstanceDance;

// Asignamos nombre al AXI TIMER 0 y a su linea de interrupcion GIC.
#define TIMER_DEVICE_ID_DANCE      XPAR_AXI_TIMER_1_DEVICE_ID
#define TIMER_INTR_ID_DANCE        XPAR_FABRIC_AXI_TIMER_1_INTERRUPT_INTR

// Funcion que inicializa el TIMER asociado al audio:
int Dance_Initialize_Timer(u16 DeviceId) {
    int Status; // Status recibe el macro (numero entero) de XTmrCtr_Initialize

    // Inicializacion del timer: Recibe puntero al timer y su id.
    Status = XTmrCtr_Initialize(&TimerInstanceDance, DeviceId);

    // Retorna mensaje de error si falla inicializacion:
    if (Status != XST_SUCCESS) {
        xil_printf("Falla inicializacion del timer de baile\r\n");
        return XST_FAILURE;
    }

    // Pointer del timer, canal 0 realiza conteo, lo hace de manera descendente.
    XTmrCtr_SetOptions(&TimerInstanceDance, 0, XTC_DOWN_COUNT_OPTION | XTC_INT_MODE_OPTION);

    // Retorna "exito en inicializacion si no hay error".
    return XST_SUCCESS;
}

// Funcion para configurar el sistema de interrupcion del baile (recibe un pointer al controlador
// del GIC tal que recibe un tipo de dato XScuGic y retorna Status)
int Dance_Setup_Interrupt_System(XScuGic *IntcInstancePtr) {
    int Status;

    // Conexion de la interrupcion: Recibe el controlador GIC que gestiona la interrupcion,
    // El id del temporizador, la funcion que sera ejecutada durante la interrupcion, direccion
    // de instancia al temporizador.
    Status = XScuGic_Connect(IntcInstancePtr, TIMER_INTR_ID_DANCE,
                             (Xil_ExceptionHandler)Dance_Timer_Interrupt_Handler,
                             (void *)&TimerInstanceDance);
    if (Status != XST_SUCCESS) {
        xil_printf("Fallo en conectarse el Dance Timer Interrupt Handler\r\n");
        return XST_FAILURE;
    }

    // Habilita la interrupcion: Cada vez que hay una interrupcion, se ejecuta la funcion declarada
    XScuGic_Enable(IntcInstancePtr, TIMER_INTR_ID_DANCE);
    return XST_SUCCESS;
}

// Handler de la interrupcion de sonido
void Dance_Timer_Interrupt_Handler(void *CallBackRef) {

	// CallBackRef (puntero generico) es casteado al tipo XTmrCtr (tipo especifico):
    XTmrCtr *InstancePtr = (XTmrCtr *)CallBackRef;

    // Limpieza de la interrupcion (lectura y escritura como  mecanismo de acknowledge):

    // Lectura del registro del temporizador 0 desde el hardware:
    u32 ControlStatusReg = XTmrCtr_GetControlStatusReg(InstancePtr->BaseAddress, 0);
    // Escritura del registro del temporizador 0 para limpiar el flag de interrupcion:
    XTmrCtr_SetControlStatusReg(InstancePtr->BaseAddress, 0, ControlStatusReg);

    // Se detiene el timer 0:
    XTmrCtr_Stop(InstancePtr, 0);


    // Se toca la siguiente nota
    Next_Dance_Step();
    //Next_Dance_Step();
}

// Inicializa Flags y Pose en sus valores iniciales
void Reset_Dance_Step_Flags_and_Pose() {

	// Left arrow variables
	left_flag1 = 0;
	left_flag2 = 0;
	left_flag3 = 0;
	left_flag4 = 0;
	left_flag5 = 0;
	left_pose1 = -15;
	left_pose2 = -15;
	left_pose3 = -15;
	left_pose4 = -15;
	left_pose5 = -15;

	// Down arrow variables
	down_flag1 = 0;
	down_flag2 = 0;
	down_flag3 = 0;
	down_flag4 = 0;
	down_flag5 = 0;
	down_pose1 = -15;
	down_pose2 = -15;
	down_pose3 = -15;
	down_pose4 = -15;
	down_pose5 = -15;

	// Up arrow variables
	up_flag1 = 0;
	up_flag2 = 0;
	up_flag3 = 0;
	up_flag4 = 0;
	up_flag5 = 0;
	up_pose1 = -15;
	up_pose2 = -15;
	up_pose3 = -15;
	up_pose4 = -15;
	up_pose5 = -15;

	// Right arrow variables
	right_flag1 = 0;
	right_flag2 = 0;
	right_flag3 = 0;
	right_flag4 = 0;
	right_flag5 = 0;
	right_pose1 = -15;
	right_pose2 = -15;
	right_pose3 = -15;
	right_pose4 = -15;
	right_pose5 = -15;

	// Up arrow variables
	turn_left_flag1 = 0;
	turn_left_flag2 = 0;
	turn_left_pose1 = -20;
	turn_left_pose2 = -20;

	// Right arrow variables
	turn_right_flag1 = 0;
	turn_right_flag2 = 0;
	turn_right_pose1 = -20;
	turn_right_pose2 = -20;
}

void Next_Dance_Step() {
	//xil_printf("Dance interrupt para step:%d\r\n", current_step);

	uint32_t NONE_ref  = 0;
	uint32_t LEFT_ref  = 1;
	uint32_t DOWN_ref  = 2;
	uint32_t UP_ref    = 3;
	uint32_t RIGHT_ref = 4;
	uint32_t TURN_LEFT_ref  = 5;
	uint32_t TURN_RIGHT_ref = 6;


    // Si no se ha terminado la melodia:
    if (current_step < dance_length) {
    	// Lectura de la informacion de melody.c
        uint32_t dance_move = dance[current_step].dancemove;  // Lectura de la dance_move
        uint32_t duration_ms = dance[current_step].duration;   // Lectura de duracion de step
        uint32_t duration_counts = duration_ms * 100000;       // Ajustamos la duracion a ciclos de clk (100 MHz)

        // Left
		if(dance_move == LEFT_ref){
			if(left_flag1 == 0){
				left_flag1 = 1;
			}else if(left_flag2 == 0){
				left_flag2 = 1;
			}else if(left_flag3 == 0){
				left_flag3 = 1;
			}else if(left_flag4 == 0){
				left_flag4 = 1;
			}else if(left_flag5 == 0){
				left_flag5 = 1;
			}
		}

		// Right
		if(dance_move == RIGHT_ref){
			if(right_flag1 == 0){
				right_flag1 = 1;
			}else if(right_flag2 == 0){
				right_flag2 = 1;
			}else if(right_flag3 == 0){
				right_flag3 = 1;
			}else if(right_flag4 == 0){
				right_flag4 = 1;
			}else if(right_flag5 == 0){
				right_flag5 = 1;
			}
		}

		// UP
		if(dance_move == UP_ref){
			//xil_printf("up");
			if(up_flag1 == 0){
				up_flag1 = 1;
			}else if(up_flag2 == 0){
				up_flag2 = 1;
			}else if(up_flag3 == 0){
				up_flag3 = 1;
			}else if(up_flag4 == 0){
				up_flag4 = 1;
			}else if(up_flag5 == 0){
				up_flag5 = 1;
			}
		}

		// Left
		if(dance_move == DOWN_ref){
			if(down_flag1 == 0){
				down_flag1 = 1;
			}else if(down_flag2 == 0){
				down_flag2 = 1;
			}else if(down_flag3 == 0){
				down_flag3 = 1;
			}else if(down_flag4 == 0){
				down_flag4 = 1;
			}else if(down_flag5 == 0){
				down_flag5 = 1;
			}
		}

		// Turn left
		if(dance_move == TURN_LEFT_ref){
			if(turn_left_flag1 == 0){
				turn_left_flag1 = 1;
			}else if(turn_left_flag2 == 0){
				turn_left_flag2 = 1;
			}
		}

		// Turn right
		if(dance_move == TURN_RIGHT_ref){
			if(turn_right_flag1 == 0){
				turn_right_flag1 = 1;
			}else if(turn_right_flag2 == 0){
				turn_right_flag2 = 1;
			}
		}


        //uint32_t frequency = melody[current_note].frequency; // Lectura de la frecuencia
		//uint32_t duration_ms = melody[current_note].duration; // Lectura de duracion de nota
		//uint32_t duration_counts = duration_ms * 100000; // Ajustamos la duracion a ciclos de clk (100 MHz)

        // Buffer para la duracion del timer (mismo valor que duration_counts)
        uint32_t timer_counts = duration_ms * 100000;

        // Configura el valor de reseteo del timer 0 para hacer la interrupcion:
        XTmrCtr_SetResetValue(&TimerInstanceDance, 0, timer_counts);

        // Inicia el timer 0
        XTmrCtr_Start(&TimerInstanceDance, 0);

        // Avance al siguiente step:
        current_step++;

        // Si ya se termino la melodia, se loopea:
    } else if (current_step >= dance_length &&  dance_length > 0) {
        xil_printf("Baile termino de reproducirse.\r\n");
        //current_note = 0;
        //Play_Next_Note();
    }

}

void Run_Arrow_Animations(int light_mode)	{

	uint32_t LEFT_ref  = 1;
	uint32_t DOWN_ref  = 2;
	uint32_t UP_ref    = 3;
	uint32_t RIGHT_ref = 4;
	uint32_t TURN_LEFT_ref  = 5;
	uint32_t TURN_RIGHT_ref = 6;

	// Modifica la velocidad en que se mueven las flechas
	int n = 9;

	// Left
	if(left_flag1){
		Animate_Arrow(LEFT_ref, &left_pose1, &left_flag1, n, &blocked_left_window1, light_mode);
	}
	if(left_flag2){
		Animate_Arrow(LEFT_ref, &left_pose2, &left_flag2, n, &blocked_left_window2, light_mode);
	}
	if(left_flag3){
		Animate_Arrow(LEFT_ref, &left_pose3, &left_flag3, n, &blocked_left_window3, light_mode);
	}
	if(left_flag4){
		Animate_Arrow(LEFT_ref, &left_pose4, &left_flag4, n, &blocked_left_window4, light_mode);
	}
	if(left_flag5){
		Animate_Arrow(LEFT_ref, &left_pose5, &left_flag5, n, &blocked_left_window5, light_mode);
	}

	// Right
	if(right_flag1){
		Animate_Arrow(RIGHT_ref, &right_pose1, &right_flag1, n, &blocked_right_window1, light_mode);
	}
	if(right_flag2){
		Animate_Arrow(RIGHT_ref, &right_pose2, &right_flag2, n, &blocked_right_window2, light_mode);
	}
	if(right_flag3){
		Animate_Arrow(RIGHT_ref, &right_pose3, &right_flag3, n, &blocked_right_window3, light_mode);
	}
	if(right_flag4){
		Animate_Arrow(RIGHT_ref, &right_pose4, &right_flag4, n, &blocked_right_window4, light_mode);
	}
	if(right_flag5){
		Animate_Arrow(RIGHT_ref, &right_pose5, &right_flag5, n, &blocked_right_window5, light_mode);
	}

	// Up
	if(up_flag1){
		Animate_Arrow(UP_ref, &up_pose1, &up_flag1, n, &blocked_up_window1, light_mode);
	}
	if(up_flag2){
		Animate_Arrow(UP_ref, &up_pose2, &up_flag2, n, &blocked_up_window2, light_mode);
	}
	if(up_flag3){
		Animate_Arrow(UP_ref, &up_pose3, &up_flag3, n, &blocked_up_window3, light_mode);
	}
	if(up_flag4){
		Animate_Arrow(UP_ref, &up_pose4, &up_flag4, n, &blocked_up_window4, light_mode);
	}
	if(up_flag5){
		Animate_Arrow(UP_ref, &up_pose5, &up_flag5, n, &blocked_up_window5, light_mode);
	}

	// Down
	if(down_flag1){
		Animate_Arrow(DOWN_ref, &down_pose1, &down_flag1, n, &blocked_down_window1, light_mode);
	}
	if(down_flag2){
		Animate_Arrow(DOWN_ref, &down_pose2, &down_flag2, n, &blocked_down_window2, light_mode);
	}
	if(down_flag3){
		Animate_Arrow(DOWN_ref, &down_pose3, &down_flag3, n, &blocked_down_window3, light_mode);
	}
	if(down_flag4){
		Animate_Arrow(DOWN_ref, &down_pose4, &down_flag4, n, &blocked_down_window4, light_mode);
	}
	if(down_flag5){
		Animate_Arrow(DOWN_ref, &down_pose5, &down_flag5, n, &blocked_down_window5, light_mode);
	}

	// Turn left
	if(turn_left_flag1){
		Animate_Arrow(TURN_LEFT_ref, &turn_left_pose1, &turn_left_flag1, n, &blocked_turn_left_window1, light_mode);
	}
	if(turn_left_flag2){
		Animate_Arrow(TURN_LEFT_ref, &turn_left_pose2, &turn_left_flag2, n, &blocked_turn_left_window2, light_mode);
	}

	// Turn right
	if(turn_right_flag1){
		Animate_Arrow(TURN_RIGHT_ref, &turn_right_pose1, &turn_right_flag1, n, &blocked_turn_right_window1, light_mode);
	}
	if(turn_right_flag2){
		Animate_Arrow(TURN_RIGHT_ref, &turn_right_pose2, &turn_right_flag2, n, &blocked_turn_right_window2, light_mode);
	}
}

void Animate_Arrow(int current_step, int *pose, int *flag, int n, int *windowblocked, int light_mode){

	uint32_t LEFT_ref  = 1;
	uint32_t DOWN_ref  = 2;
	uint32_t UP_ref    = 3;
	uint32_t RIGHT_ref = 4;
	uint32_t TURN_LEFT_ref  = 5;
	uint32_t TURN_RIGHT_ref = 6;

	if(*pose<110){

		if(current_step==LEFT_ref){
			// Left
			GUI_ERASE_LEFT_ARROW(*pose, light_mode);
			*pose = *pose + n;
			GUI_DRAW_LEFT_ARROW(*pose);
		}else if(current_step==DOWN_ref){
			// Down
			GUI_ERASE_DOWN_ARROW(*pose, light_mode);
			*pose = *pose + n;
			GUI_DRAW_DOWN_ARROW(*pose);
		}else if(current_step==UP_ref){
			// Up
			GUI_ERASE_UP_ARROW(*pose, light_mode);
			*pose = *pose + n;
			GUI_DRAW_UP_ARROW(*pose);
		}else if(current_step==RIGHT_ref){
			// Right
			GUI_ERASE_RIGHT_ARROW(*pose, light_mode);
			*pose = *pose + n;
			GUI_DRAW_RIGHT_ARROW(*pose);
		}else if(current_step==TURN_LEFT_ref){
			// Turn left
			GUI_ERASE_TURN_LEFT(*pose-5, light_mode);
			*pose = *pose + n;
			GUI_DRAW_TURN_LEFT(*pose-5);
		}else if(current_step==TURN_RIGHT_ref){
			// Turn right
			GUI_ERASE_TURN_RIGHT(*pose-5, light_mode);
			*pose = *pose + n;
			GUI_DRAW_TURN_RIGHT(*pose-5);
		}

	} else if(*pose <135){
		if(current_step==LEFT_ref){
			// Left
			GUI_ERASE_LEFT_ARROW(*pose, light_mode);
			*pose = *pose + n;
		}else if(current_step==DOWN_ref){
			// Down
			GUI_ERASE_DOWN_ARROW(*pose, light_mode);
			*pose = *pose + n;
		}else if(current_step==UP_ref){
			// Up
			GUI_ERASE_UP_ARROW(*pose, light_mode);
			*pose = *pose + n;
		}else if(current_step==RIGHT_ref){
			// Right
			GUI_ERASE_RIGHT_ARROW(*pose, light_mode);
			*pose = *pose + n;
		}else if(current_step==TURN_LEFT_ref){
			// Turn left
			GUI_ERASE_TURN_LEFT(*pose-5, light_mode);
			*pose = *pose + n;
		}else if(current_step==TURN_RIGHT_ref){
			// Turn right
			GUI_ERASE_TURN_RIGHT(*pose-5, light_mode);
			*pose = *pose + n;
		}
	}
	else {
		*pose = -15;
		*flag = 0;
		if((current_step==TURN_LEFT_ref)||(current_step==TURN_RIGHT_ref)){
			*pose = -20;
		}
	}

	if(*pose>98){
		// Activamos el window a partir de este valor
		Check_score(&score, windowblocked, current_step);
	}

	if(*pose==-15){
		// Reseteamos el blocked y el arrow_disappeared
		*windowblocked = 0;
	}
}

void Check_score(int *score, int *windowblocked, int current_step){

	uint32_t LEFT_ref  = 1;
	uint32_t DOWN_ref  = 2;
	uint32_t UP_ref    = 3;
	uint32_t RIGHT_ref = 4;
	uint32_t TURN_LEFT_ref  = 5;
	uint32_t TURN_RIGHT_ref = 6;

	int match = 0;
	int match1 = 0;

	joyx_val = read_joyx();
	joyy_val = read_joyy();
	acx_val = read_acx();
	//xil_printf("%d\n",acx_val);

	if(current_step == LEFT_ref){
		if(joyx_val<300){
			match = 1;
		}
	} else if(current_step == DOWN_ref){
		if(joyy_val<300){
			match = 1;
		}
	} else if(current_step == UP_ref){
		if(joyy_val>800){
			match = 1;
		}
	} else if(current_step == RIGHT_ref){
		if(joyx_val>700){
			match = 1;
		}
	} else if(current_step == TURN_LEFT_ref){
		if(acx_val<450){
			match1 = 1;
		}
	} else if(current_step == TURN_RIGHT_ref){
		if(acx_val>550){
			match1 = 1;
		}
	}


	if(match){
		if(*windowblocked!=1){
			*score = *score + 100;
			*windowblocked=1;
		}
	} else if(match1){
		if(*windowblocked!=1){
			*score = *score + 500;
			*windowblocked=1;
		}
	}

}
