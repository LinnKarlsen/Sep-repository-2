#include <stdio.h>
#include <sleep.h>
#include <time.h>
#include <unistd.h>
#include "ff.h"
#include "xsdps.h"
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
#include "xstatus.h"
#include "Delay.h"
#include "LCD_SPI.h"
#include "LCD_Driver.h"
#include "LCD_GUI.h"
#include "ADC.h"
#include "I2C.h"
#include "xuartps.h"
#include "xscugic.h"
#include "xtmrctr.h"
#include "sound.h"
#include "melody.h"
#include "dance.h"
#include "careography.h"

// ==================== Definiciones de constantes  ====================
#define puntaje_maximo 20
#define LOW_LIGHT_INTENSITY_THRESHOLD   500
#define HIGH_LIGHT_INTENSITY_THRESHOLD  35000
#define BACKGROUND  WHITE
#define FOREGROUND  BLUE
#define DELAY       1000

// IDs de dispositivos
#define TIMER_DEVICE_ID_SOUND          XPAR_AXI_TIMER_0_DEVICE_ID
#define TIMER_INTR_ID_SOUND            XPAR_FABRIC_AXI_TIMER_0_INTERRUPT_INTR
#define TIMER_DEVICE_ID_DANCE          XPAR_AXI_TIMER_1_DEVICE_ID
#define TIMER_INTR_ID_DANCE            XPAR_FABRIC_AXI_TIMER_1_INTERRUPT_INTR
#define TIMER_DEVICE_ID_GRAPHICS       XPAR_AXI_TIMER_2_DEVICE_ID
#define TIMER_INTR_ID_GRAPHICS         XPAR_FABRIC_AXI_TIMER_2_INTERRUPT_INTR
#define TIMER_DEVICE_ID_STATE_MACHINE  XPAR_AXI_TIMER_3_DEVICE_ID
#define TIMER_INTR_ID_STATE_MACHINE    XPAR_FABRIC_AXI_TIMER_3_INTERRUPT_INTR
#define INTC_DEVICE_ID                 XPAR_SCUGIC_SINGLE_DEVICE_ID
#define GPIO_DEVICE_ID_1               XPAR_AXI_GPIO_1_DEVICE_ID
#define GPIO_INTR_ID                   XPAR_FABRIC_AXI_GPIO_1_IP2INTC_IRPT_INTR
#define GPIO_DEVICE_ID_2               XPAR_AXI_GPIO_2_DEVICE_ID
#define SD_DEVICE_ID                   XPAR_XSDPS_0_DEVICE_ID

// ==================== Variables externas (definidas en otros archivos) ====================
extern XGpio gpio0;
extern XSpi  SpiInstance;
extern XSpi  SpiInstance1;
extern const unsigned char font[];
extern Note melody[];
extern int melody_length;
extern Step dance[];
extern int dance_length;

// ==================== Variables volátiles compartidas (DEFINIDAS AQUÍ) ====================
// Estas variables son modificadas por los handlers de interrupción y leídas en main
volatile int state_machine_update_needed = 0;
volatile int graphics_update_needed = 0;
volatile int game_sleep = 0;

// ==================== Variables globales de control de juego ====================
volatile int score = 0;
volatile int joyx_val = 0;
volatile int joyy_val = 0;
volatile int acx_val = 0;
volatile int song_end = 0;
volatile int pose;
int mic_val = 0;

// Sistema de puntajes
int historial_puntaje[puntaje_maximo];
int contador_puntaje = 0;

// Sistema de archivos SD
static FATFS fatfs;
static FIL fil;
static XSdPs sd_ctl;
static XSdPs_Config *sd_cfg;

// Instancias de hardware -
XGpio gpio1;  // GPIO para sensor de luz
XGpio gpio2;  // GPIO para botones
XTmrCtr TimerInstanceGraphics;
XTmrCtr TimerInstanceStateMachine;
XScuGic InterruptController;

// Variables para animación de flechas - "LEFT"
int left_flag1 = 0, left_flag2 = 0, left_flag3 = 0, left_flag4 = 0, left_flag5 = 0;
int left_pose1 = -15, left_pose2 = -15, left_pose3 = -15, left_pose4 = -15, left_pose5 = -15;

// Variables para animación de flechas - "DOWN"
int down_flag1 = 0, down_flag2 = 0, down_flag3 = 0, down_flag4 = 0, down_flag5 = 0;
int down_pose1 = -15, down_pose2 = -15, down_pose3 = -15, down_pose4 = -15, down_pose5 = -15;

// Variables para animación de flechas - "UP"
int up_flag1 = 0, up_flag2 = 0, up_flag3 = 0, up_flag4 = 0, up_flag5 = 0;
int up_pose1 = -15, up_pose2 = -15, up_pose3 = -15, up_pose4 = -15, up_pose5 = -15;

// Variables para animación de flechas - "RIGHT"
int right_flag1 = 0, right_flag2 = 0, right_flag3 = 0, right_flag4 = 0, right_flag5 = 0;
int right_pose1 = -15, right_pose2 = -15, right_pose3 = -15, right_pose4 = -15, right_pose5 = -15;

// Variables para animación de giros - "TURN LEFT"
int turn_left_flag1 = 0, turn_left_flag2 = 0;
int turn_left_pose1 = -15, turn_left_pose2 = -15;

// Variables para animación de giros - "TURN RIGHT"
int turn_right_flag1 = 0, turn_right_flag2 = 0;
int turn_right_pose1 = -15, turn_right_pose2 = -15;

// Ventanas de puntaje
int left_window1 = 0, left_window2 = 0, left_window3 = 0, left_window4 = 0, left_window5 = 0;
int right_window1 = 0, right_window2 = 0, right_window3 = 0, right_window4 = 0, right_window5 = 0;
int up_window1 = 0, up_window2 = 0, up_window3 = 0, up_window4 = 0, up_window5 = 0;
int down_window1 = 0, down_window2 = 0, down_window3 = 0, down_window4 = 0, down_window5 = 0;

// Ventanas de bloqueo
int blocked_left_window1 = 0, blocked_left_window2 = 0, blocked_left_window3 = 0, blocked_left_window4 = 0, blocked_left_window5 = 0;
int blocked_right_window1 = 0, blocked_right_window2 = 0, blocked_right_window3 = 0, blocked_right_window4 = 0, blocked_right_window5 = 0;
int blocked_up_window1 = 0, blocked_up_window2 = 0, blocked_up_window3 = 0, blocked_up_window4 = 0, blocked_up_window5 = 0;
int blocked_down_window1 = 0, blocked_down_window2 = 0, blocked_down_window3 = 0, blocked_down_window4 = 0, blocked_down_window5 = 0;
int blocked_turn_left_window1 = 0, blocked_turn_left_window2 = 0;
int blocked_turn_right_window1 = 0, blocked_turn_right_window2 = 0;

// ==================== Prototipos de funciones ====================
void Graphics_Timer_Interrupt_Handler(void *CallBackRef);
void State_Machine_Timer_Interrupt_Handler(void *CallBackRef);
void Light_Interrupt_Handler(void *CallbackRef);
void Buzzer_Mute_UART_Command(void);
void print_puntajes(void);
void sumar_puntajes(int);
void top5_puntajes(int top5[5]);
int escritura_sd(void);

// ==================== FUNCIÓN PRINCIPAL ====================
int main() {
    int podio_animado = 0;
    int Status;

    init_platform();
    xil_printf("=== Iniciando sistema de juego Dance Revolution ===\r\n");

    // -------------------- Inicialización GPIO 0 --------------------
    Status = XGpio_Initialize(&gpio0, XPAR_AXI_GPIO_0_DEVICE_ID);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion GPIO 0\r\n");
        return XST_FAILURE;
    }

    // -------------------- Inicialización GPIO 1 (Sensor de luz) --------------------
    Status = XGpio_Initialize(&gpio1, GPIO_DEVICE_ID_1);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion GPIO 1 (sensor luz)\r\n");
        return XST_FAILURE;
    }
    XGpio_SetDataDirection(&gpio1, 1, 0xFFFFFFFF);

    // -------------------- Inicialización GPIO 2 (Botones) --------------------
    Status = XGpio_Initialize(&gpio2, GPIO_DEVICE_ID_2);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion GPIO 2 (botones)\r\n");
        return XST_FAILURE;
    }
    XGpio_SetDataDirection(&gpio2, 1, 0xFFFFFFFF);
    XGpio_SetDataDirection(&gpio2, 2, 0xFFFFFFFF);

    // -------------------- Inicialización SPI para LCD --------------------
    Status = XSpi_Init(&SpiInstance, SPI_DEVICE_ID);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion SPI (LCD)\r\n");
        return XST_FAILURE;
    }

    // -------------------- Inicialización SPI para ADC --------------------
    Status = init_adc(&SpiInstance1, SPI_DEVICE_ID_1);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion SPI (ADC)\r\n");
        return XST_FAILURE;
    }

    // -------------------- Inicialización I2C --------------------
    Status = init_IIC();
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion I2C\r\n");
        return XST_FAILURE;
    }

    // -------------------- Inicialización LCD --------------------
    xil_printf("Inicializando pantalla LCD...\r\n");
    LCD_SCAN_DIR LCD_ScanDir = SCAN_DIR_DFT;
    LCD_Init(LCD_ScanDir);
    LCD_Clear(GUI_BACKGROUND);
    GUI_INTRO();
    xil_printf("LCD lista\r\n");

    // -------------------- Inicialización del controlador de interrupciones (GIC) --------------------
    xil_printf("Configurando controlador de interrupciones...\r\n");

    XScuGic_Config *IntcConfig;
    IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
    if (NULL == IntcConfig) {
        xil_printf("ERROR: No se encontro configuracion GIC\r\n");
        return XST_FAILURE;
    }

    Status = XScuGic_CfgInitialize(&InterruptController, IntcConfig, IntcConfig->CpuBaseAddress);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion GIC\r\n");
        return XST_FAILURE;
    }

    Xil_ExceptionInit();
    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
                                (Xil_ExceptionHandler)XScuGic_InterruptHandler,
                                &InterruptController);
    Xil_ExceptionEnable();

    // -------------------- Inicialización del sistema de audio --------------------
    xil_printf("Configurando timer de audio...\r\n");

    Status = Sound_Initialize_Timer(TIMER_DEVICE_ID_SOUND);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo timer de audio\r\n");
        return XST_FAILURE;
    }

    Status = Sound_Setup_Interrupt_System(&InterruptController);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo interrupciones de audio\r\n");
        return XST_FAILURE;
    }

    // -------------------- Inicialización del sistema de baile --------------------
    xil_printf("Configurando timer de coreografia...\r\n");

    Status = Dance_Initialize_Timer(TIMER_DEVICE_ID_DANCE);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo timer de baile\r\n");
        return XST_FAILURE;
    }

    Status = Dance_Setup_Interrupt_System(&InterruptController);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo interrupciones de baile\r\n");
        return XST_FAILURE;
    }

    // -------------------- Inicialización del timer de gráficos --------------------
    xil_printf("Configurando timer de graficos...\r\n");

    Status = XTmrCtr_Initialize(&TimerInstanceGraphics, TIMER_DEVICE_ID_GRAPHICS);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo timer de graficos\r\n");
        return XST_FAILURE;
    }

    XTmrCtr_SetOptions(&TimerInstanceGraphics, 0,
                       XTC_DOWN_COUNT_OPTION | XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);
    XTmrCtr_SetResetValue(&TimerInstanceGraphics, 0, 10000000);

    Status = XScuGic_Connect(&InterruptController, TIMER_INTR_ID_GRAPHICS,
                            (Xil_InterruptHandler)Graphics_Timer_Interrupt_Handler,
                            (void *)&TimerInstanceGraphics);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo conexion interrupcion graficos\r\n");
        return XST_FAILURE;
    }
    XScuGic_Enable(&InterruptController, TIMER_INTR_ID_GRAPHICS);

    // -------------------- Inicialización del timer de máquina de estados --------------------
    xil_printf("Configurando timer de State Machine...\r\n");

    Status = XTmrCtr_Initialize(&TimerInstanceStateMachine, TIMER_DEVICE_ID_STATE_MACHINE);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo timer de State Machine\r\n");
        return XST_FAILURE;
    }

    XTmrCtr_SetOptions(&TimerInstanceStateMachine, 0,
                       XTC_DOWN_COUNT_OPTION | XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);
    XTmrCtr_SetResetValue(&TimerInstanceStateMachine, 0, 50000000);

    Status = XScuGic_Connect(&InterruptController, TIMER_INTR_ID_STATE_MACHINE,
                            (Xil_InterruptHandler)State_Machine_Timer_Interrupt_Handler,
                            (void *)&TimerInstanceStateMachine);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo conexion de interrupciones de State Machine\r\n");
        return XST_FAILURE;
    }
    XScuGic_Enable(&InterruptController, TIMER_INTR_ID_STATE_MACHINE);

    // ----------------- Inicializar controlador de SD --------------------------------------
    sd_cfg = XSdPs_LookupConfig(SD_DEVICE_ID);
    if (NULL == sd_cfg) {
        xil_printf("ERROR: No se encontro configuracion de SD\r\n");
        return XST_FAILURE;
    }

    Status = XSdPs_CfgInitialize(&sd_ctl, sd_cfg, sd_cfg->BaseAddress);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo inicializacion de SD\r\n");
        return XST_FAILURE;
    }

    // -------------------- Configuración de interrupciones del sensor de luz --------------------
    Status = XScuGic_Connect(&InterruptController, GPIO_INTR_ID,
                             (Xil_ExceptionHandler)Light_Interrupt_Handler,
                             (void *)&gpio1);
    if (Status != XST_SUCCESS) {
        xil_printf("ERROR: Fallo conexion interrupcion sensor luz\r\n");
        return XST_FAILURE;
    }

    XGpio_InterruptEnable(&gpio1, XGPIO_IR_CH1_MASK);
    XGpio_InterruptGlobalEnable(&gpio1);
    XScuGic_Enable(&InterruptController, GPIO_INTR_ID);

    // -------------------- Configuración de prioridades de interrupciones --------------------
    XScuGic_SetPriorityTriggerType(&InterruptController, TIMER_INTR_ID_STATE_MACHINE, 0x20, 0x3);
    XScuGic_SetPriorityTriggerType(&InterruptController, GPIO_INTR_ID, 0x10, 0x3);
    XScuGic_SetPriorityTriggerType(&InterruptController, TIMER_INTR_ID_GRAPHICS, 0x40, 0x3);

    // -------------------- Inicio de timers --------------------
    XTmrCtr_Start(&TimerInstanceGraphics, 0);
    XTmrCtr_Start(&TimerInstanceStateMachine, 0);

    xil_printf("Sistema inicializado correctamente\r\n");

    // -------------------- Carga de melodía y coreografía --------------------
    initialize_melody(available_melodies[1], melody, &melody_length);
    initialize_dance(available_dances[0], dance, &dance_length);

    xil_printf("Preparado para iniciar reproduccion...\r\n");

    // ==================== BUCLE PRINCIPAL DEL JUEGO ====================
    char score_display[16] = {};
    int opt_val = 0;
    int btn0, btn1;
    int btn0_prev = 1;
    int btn1_prev = 1;
    int light_mode = 0;
    int game_init_complete = 0;
    enum state_t {START, GAME_INIT, GAME, PODIUM};
    static enum state_t state = START;

    int start_ready = 0;

    char bienvenida[64] = "BTN0 para partir";
    char loading[16] = "Loading...";

    xil_printf("\nComandos UART: '1'=mute, '0'=unmute, 's'=historial, 'w'=guardar SD\r\n");

    while (1) {
        Buzzer_Mute_UART_Command();

        // ==================== Actualización de gráficos ====================
        if (graphics_update_needed) {
            switch (state) {
                case START:
                    if (start_ready == 0) {
                        GUI_INTRO();
                        GUI_DisString_EN(20, 105, bienvenida, &Font8, GUI_BACKGROUND, WHITE);
                        start_ready = 1;
                    }
                    break;

                case GAME_INIT:
                    start_ready = 0;
                    GUI_DisString_EN(34, 115, loading, &Font8, GUI_BACKGROUND, WHITE);

                    opt_val = read_opt();
                    light_mode = (opt_val > 20000) ? 1 : 0;

                    if (light_mode == 0) {
                        GUI_DANCE_FLOOR();
                    } else {
                        GUI_DANCE_FLOOR_LIGHT();
                    }

                    GUI_SCORE_BOARD();
                    Reset_Dance_Step_Flags_and_Pose();
                    score = 0;

                    song_end = 0;
                    current_note = 0;
                    current_step = 0;
                    Play_Next_Note();
                    Next_Dance_Step();

                    game_init_complete = 1;
                    break;

                case GAME:
                    game_init_complete = 0;
                    Run_Arrow_Animations(light_mode);
                    break;

                case PODIUM:
                    if (!podio_animado) {
                        LCD_Clear(GUI_BACKGROUND);

                        GUI_DisString_EN(28, 5, "TOP 5 SCORES", &Font12, GUI_BACKGROUND, YELLOW);

                        int top5[5];
                        top5_puntajes(top5);

                        char rank_display[20];
                        int y_position = 25;
                        int y_spacing = 18;

                        for (int i = 0; i < 5; i++) {
                            if (top5[i] > 0) {
                                sprintf(rank_display, "%d. %d pts", i + 1, top5[i]);

                                int text_color;
                                if (i == 0) text_color = YELLOW;
                                else if (i == 1) text_color = CYAN;
                                else if (i == 2) text_color = MAGENTA;
                                else text_color = WHITE;

                                if (top5[i] == score && i < 3) {
                                    GUI_DisString_EN(8, y_position, ">", &Font12, GUI_BACKGROUND, text_color);
                                }

                                GUI_DisString_EN(18, y_position, rank_display, &Font12, GUI_BACKGROUND, text_color);
                            } else {
                                sprintf(rank_display, "%d. ---", i + 1);
                                GUI_DisString_EN(18, y_position, rank_display, &Font12, GUI_BACKGROUND, WHITE);
                            }

                            y_position += y_spacing;
                        }

                        char last_game[24];
                        sprintf(last_game, "Ultima: %d", score);
                        GUI_DisString_EN(18, 108, last_game, &Font8, GUI_BACKGROUND, GREEN);

                        GUI_DisString_EN(10, 118, "BTN0=volver", &Font8, GUI_BACKGROUND, WHITE);

                        podio_animado = 1;
                    }
                    break;
            }
            graphics_update_needed = 0;
        }

        // ==================== Actualización de máquina de estados ====================
        if (state_machine_update_needed) {
            btn0 = XGpio_DiscreteRead(&gpio2, 1);
            btn1 = XGpio_DiscreteRead(&gpio2, 2);
            mic_val = read_MIC();
            int lets_dance = 0;
            if (mic_val < 300 || mic_val > 700) {
            	lets_dance = 1;
            }
            switch (state) {
				case START:
					if ((btn0 != 1) && btn0_prev) {
						state = GAME_INIT;
					}
					else if (lets_dance) {          // Activacion del flag
						xil_printf("Inicialización por micrófono! mic_val=%d\r\n", mic_val);
						lets_dance = 0;             // Limpiamos el flag
						state = GAME_INIT;           // Inicio del juego
					}
					break;
                case GAME_INIT:
                    if (game_init_complete) {
                        state = GAME;
                        Buzzer_Write_Bit12(0);
                    }
                    break;

                case GAME:
                    if (game_sleep) {
                        state = PODIUM;
                        Buzzer_Write_Bit12(1);
                    } else if ((btn0 != 1) && btn0_prev) {
                    	Buzzer_Write_Bit12(1);
                        sumar_puntajes(score);
                        xil_printf("Partida terminada manualmente. Puntaje: %d\r\n", score);
                        state = START;
                    } else if (song_end) {
                    	Buzzer_Write_Bit12(1);
                        sumar_puntajes(score);
                        xil_printf("Cancion terminada. Puntaje final: %d\r\n", score);
                        state = PODIUM;
                    }

                    GUI_DisString_EN(80, 11, score_display, &Font8, GUI_BACKGROUND, GUI_BACKGROUND);
                    sprintf(score_display, "%d", score);
                    GUI_DisString_EN(80, 11, score_display, &Font8, GUI_BACKGROUND, YELLOW);
                    break;

                case PODIUM:
                    if ((btn0 != 1) && btn0_prev) {
                        state = START;
                        game_sleep = 0;
                        podio_animado = 0;

                        if (escritura_sd() == XST_SUCCESS) {
                            xil_printf("Puntajes guardados en SD correctamente\r\n");
                        } else {
                            xil_printf("ERROR: No se pudieron guardar puntajes en SD\r\n");
                        }

                        print_puntajes();
                    }
                    break;
            }

            btn0_prev = btn0;
            btn1_prev = btn1;
            state_machine_update_needed = 0;
        }
    }

    cleanup_platform();
    return 0;
}

// ==================== MANEJADORES DE INTERRUPCIONES ====================

void Graphics_Timer_Interrupt_Handler(void *CallBackRef) {
    XTmrCtr *InstancePtr = (XTmrCtr *)CallBackRef;
    u32 ControlStatusReg = XTmrCtr_GetControlStatusReg(InstancePtr->BaseAddress, 0);
    XTmrCtr_SetControlStatusReg(InstancePtr->BaseAddress, 0, ControlStatusReg);
    graphics_update_needed = 1;
}

void State_Machine_Timer_Interrupt_Handler(void *CallBackRef) {
    XTmrCtr *InstancePtr = (XTmrCtr *)CallBackRef;
    u32 ControlStatusReg = XTmrCtr_GetControlStatusReg(InstancePtr->BaseAddress, 0);
    XTmrCtr_SetControlStatusReg(InstancePtr->BaseAddress, 0, ControlStatusReg);
    state_machine_update_needed = 1;
}

void Light_Interrupt_Handler(void *CallbackRef) {

    xil_printf("Interrupcion de sensor de luz detectada\n");
    XGpio_InterruptDisable(&gpio1, XGPIO_IR_CH1_MASK);

    int opt_val_intr = read_opt();

    if (opt_val_intr < LOW_LIGHT_INTENSITY_THRESHOLD) {
        game_sleep = 1;
        xil_printf("Modo reposo activado (luz baja)\n");
    } else if (opt_val_intr > HIGH_LIGHT_INTENSITY_THRESHOLD) {
        game_sleep = 0;
        xil_printf("Modo reposo desactivado (luz alta)\n");
    }

    (void)XGpio_InterruptClear(&gpio1, XGPIO_IR_CH1_MASK);
    XGpio_InterruptEnable(&gpio1, XGPIO_IR_CH1_MASK);
}

// ==================== FUNCIONES DE CONTROL ====================

void Buzzer_Mute_UART_Command(void) {
    if (!XUartPs_IsReceiveData(STDIN_BASEADDRESS)) {
        return;
    }

    u8 raw = XUartPs_RecvByte(STDIN_BASEADDRESS);
    char input_char = (char)raw;

    xil_printf("\r\nComando UART recibido: '%c' (0x%02X)\r\n", input_char, (unsigned)raw);

    if (input_char == '1') {
        Buzzer_Write_Bit12(1);
        xil_printf("Mute activado\r\n");
    } else if (input_char == '0') {
        Buzzer_Write_Bit12(0);
        xil_printf("Mute desactivado\r\n");
    } else if (input_char == 'w' || input_char == 'W') {
        xil_printf("Guardando puntajes en SD...\r\n");
        if (escritura_sd() == XST_SUCCESS) {
            xil_printf("Guardado exitoso\r\n");
        }
    } else if (input_char == 's' || input_char == 'S') {
        print_puntajes();
    } else {
        xil_printf("ERROR: Comando invalido. Usar: '1'=mute, '0'=unmute, 's'=historial, 'w'=guardar\r\n");
    }
}

// ==================== FUNCIONES DE GESTIÓN DE PUNTAJES ====================

void sumar_puntajes(int s) {
    if (contador_puntaje < puntaje_maximo) {
        historial_puntaje[contador_puntaje++] = s;
    } else {
        for (int i = 1; i < puntaje_maximo; i++) {
            historial_puntaje[i - 1] = historial_puntaje[i];
        }
        historial_puntaje[puntaje_maximo - 1] = s;
    }
}
/**
 * Obtiene los 5 mejores puntajes en orden descendente
 * @param top5 - Array de salida con los 5 mejores puntajes
 */
void top5_puntajes(int top5[5]) {
    // Inicializar array
    for (int i = 0; i < 5; i++) {
        top5[i] = 0;
    }

    if (contador_puntaje == 0) return;

    // Copiar historial a array temporal
    int temp[puntaje_maximo];
    for (int i = 0; i < contador_puntaje; i++) {
        temp[i] = historial_puntaje[i];
    }

    // Ordenamiento burbuja descendente
    for (int i = 0; i < contador_puntaje - 1; i++) {
        for (int j = 0; j < contador_puntaje - i - 1; j++) {
            if (temp[j] < temp[j + 1]) {
                int swap = temp[j];
                temp[j] = temp[j + 1];
                temp[j + 1] = swap;
            }
        }
    }

    // Copiar los top 5
    int limit = (contador_puntaje < 5) ? contador_puntaje : 5;
    for (int i = 0; i < limit; i++) {
        top5[i] = temp[i];
    }
}

/**
 * Imprime el historial completo de puntajes por UART
 */
void print_puntajes(void) {
    xil_printf("\r\n=== HISTORIAL DE PARTIDAS ===\r\n");
    if (contador_puntaje == 0) {
        xil_printf("No hay registros todavia\r\n");
        return;
    }

    for (int i = 0; i < contador_puntaje; i++) {
        xil_printf("Partida %d: %d puntos\r\n", i + 1, historial_puntaje[i]);
    }
    xil_printf("==============================\r\n");
}

// ==================== FUNCIÓN DE ESCRITURA EN SD ====================

/**
 * Guarda el historial de puntajes en un archivo CSV en la tarjeta SD
 * Formato: "Partida,Puntaje" (una línea por partida)
 * @return XST_SUCCESS si la operación fue exitosa, XST_FAILURE en caso contrario
 */
int escritura_sd(void) {
    FRESULT result;
    UINT bytes_written;
    const TCHAR *sd_file = "scores.txt";
    const TCHAR *path = "0:/";
    char score_buffer[512];

    xil_printf("\r\n--- Iniciando escritura en tarjeta SD ---\r\n");

    // Montar sistema de archivos FAT
    result = f_mount(&fatfs, path, 1);
    if (result != FR_OK) {
        xil_printf("ERROR: Fallo montaje de sistema de archivos (codigo %d)\r\n", result);
        return XST_FAILURE;
    }

    // Abrir/crear archivo (sobrescribe contenido anterior)
    result = f_open(&fil, sd_file, FA_WRITE | FA_CREATE_ALWAYS);
    if (result != FR_OK) {
        xil_printf("ERROR: No se pudo abrir archivo (codigo %d)\r\n", result);
        f_mount(NULL, path, 0);
        return XST_FAILURE;
    }

    // Preparar datos en formato CSV
    int pos = 0;
    pos += sprintf(&score_buffer[pos], "Partida,Puntaje\r\n");

    for (int i = 0; i < contador_puntaje; i++) {
        pos += sprintf(&score_buffer[pos], "%d,%d\r\n", i + 1, historial_puntaje[i]);
    }

    // Escribir datos en SD
    result = f_write(&fil, (const void *)score_buffer, pos, &bytes_written);
    if (result != FR_OK) {
        xil_printf("ERROR: Fallo escritura en SD (codigo %d)\r\n", result);
        f_sync(&fil);
        f_close(&fil);
        f_mount(NULL, path, 0);
        return XST_FAILURE;
    }

    // Cerrar archivo
    result = f_close(&fil);
    if (result != FR_OK) {
        xil_printf("ERROR: Fallo cierre de archivo\r\n");
        f_mount(NULL, path, 0);
        return XST_FAILURE;
    }

    // Desmontar sistema de archivos
    f_mount(NULL, path, 0);

    xil_printf("OK: Se escribieron %d bytes en '%s'\r\n", bytes_written, sd_file);
    xil_printf("    Total de partidas guardadas: %d\r\n", contador_puntaje);

    return XST_SUCCESS;
}





