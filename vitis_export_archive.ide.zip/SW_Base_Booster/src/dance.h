// Header de dance:
#ifndef DANCE_H
#define DANCE_H

#include <stdint.h>
#include "xil_types.h"
#include "xscugic.h"
#include "xtmrctr.h"

#include <stdint.h>

// Declaracion de variables globales
extern volatile int current_step;
extern XTmrCtr TimerInstanceDance;

// Funciones que se utilizaran en sound.c
int Dance_Initialize_Timer(u16 DeviceId);
int Dance_Setup_Interrupt_System(XScuGic *IntcInstancePtr);
void Dance_Timer_Interrupt_Handler(void *CallBackRef);
void Reset_Dance_Step_Flags_and_Pose();
void Next_Dance_Step();
void Run_Arrow_Animations(int light_mode);
void Animate_Arrow();
void Check_score();

#endif
